export default [
  {
    id: 1, //numerical id number
    description: "Basics of Java", //description of lesson
  },
  {
    id: 2,
    description: "Main Method and Hello World",
  },
  {
    id: 3,
    description: "Java Arrays",
  },
  {
    id: 4,
    description: "Java Loops",
  },
];
