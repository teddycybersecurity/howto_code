export default [
  {
    id: 1,
    description: "Learn the basics of Python",
  },
  {
    id: 2,
    description: "Learn about Python data types",
  },
  {
    id: 3,
    description: "Learn about Python data types",
  },
  {
    id: 4,
    description: "Learn about Python data types",
  },
];
